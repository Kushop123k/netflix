// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
const firebaseConfig = {
    apiKey: "AIzaSyA_3C0I19YEVC4bC0JRBM-JwP5RGJufYbM",
    authDomain: "react-netflix-clone-7ddd3.firebaseapp.com",
    projectId: "react-netflix-clone-7ddd3",
    storageBucket: "react-netflix-clone-7ddd3.appspot.com",
    messagingSenderId: "854936343460",
    appId: "1:854936343460:web:d53127ce4de2169ceb2731",
    measurementId: "G-H2QKB5MC20"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
/*const analytics = getAnalytics(app);*/

export const firebaseAuth = getAuth(app);